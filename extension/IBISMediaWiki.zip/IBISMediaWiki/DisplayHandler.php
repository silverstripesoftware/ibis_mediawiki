<?php
require_once("YAMLHandler.php");
require_once("PageHandler.php");

class DisplayHandler extends PageHandler{
	function __construct($title){
		$article = new Article($title);
		$this->content = $article->getContent();
	}
	function isConvertionApplicableForThisPage(){
		$array = YAMLHandler::YAMLToArray($this->content);
		if(isset($array['title']) && isset($array['type'])){
			$this->ibis = $array;
			return True;
		}
		else{
			return False;
		}
	}
	function getPageHTML($path){
		$template_main = '<div class="ibis_conversation">
		<h1 class="type_%s">%s</h1>';
		$template_response = '<li class="type_%s"><a href="'.$path.'/%s">%s</a></li>';
		//Main HTML
		$main = sprintf($template_main,$this->ibis['type'],$this->ibis['title']);
		//Response HTML
		$responses = '';
		if(isset($this->ibis['responses'])){
			$this->factory = new ArticleFactory();
			foreach($this->ibis['responses'] as $response){
				$node = $response['node'];
				$ibis = $this->GetContent($node,True);
				$type = $ibis['type'];
				$title = $ibis['title'];
				$responses .= sprintf($template_response,$type,$node,$title);
			}
			if($responses){
				$html = sprintf("%s\n<ul>%s</ul></div>",$main,$responses);
			}
		}
		else{
			$html = $main."</div>";
		}
		return $html;
	}
}
?>
